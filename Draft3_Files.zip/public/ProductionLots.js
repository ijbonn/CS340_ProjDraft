console.log('JS File Loaded')

const server = 'localhost:4747'

// document.addEventListener('DOMContentLoaded', addData);
// document.addEventListener('DOMContentLoaded', tableClick);

// function delData(id,event) {
//     console.log("delData initiated")
//     let req = new XMLHttpRequest();
//     let payload = {id: id};
//     req.open("DELETE", server, true);
//     req.setRequestHeader('Content-Type', 'application/json');
//     req.addEventListener('load', function(){
//         if (req.status >=200 && req.status <400){
//             let response = JSON.parse(req.responseText);
//             delTable(response)
//             tableClick()
//         }
//         else {console.log("delete issue")}
//     })
//     req.send(JSON.stringify(payload));
//     event.preventDefault();
// }

// function updateData(id,event) {
//     console.log("updateData initiated")
//     let req = new XMLHttpRequest();
//     let payload = {name: null, reps: null, weight: null, date: null, unit: null, id: id}

//     let table = document.getElementById('table');
//     let targetRow = null
//     //iterate through table rows
//     for (let i=0, row; row=table.rows[i]; i++){
//         if (row.cells[0].innerText== id) {
//             targetRow = row
//         }
//     }
    
//     payload.name = document.getElementById('tablename').value;
//     payload.reps = document.getElementById('tablereps').value;
//     payload.weight = document.getElementById('tableweight').value;
//     payload.date = document.getElementById('tabledate').value;
//     payload.unit = document.getElementById('tableunit').value
//     req.open("PUT", server, true);
//     req.setRequestHeader('Content-Type', 'application/json');
//     req.addEventListener('load', function(){
//         if(req.status >=200 && req.status <400){
//             let response = JSON.parse(req.responseText);
//             updateTable(response)
//             tableClick()
//         }
//         else{
//             console.log("uh oh!");
//         }
//     })
//     req.send(JSON.stringify(payload));
//     event.preventDefault();
// }

// function addData(){
//     document.getElementById('formButton').addEventListener('click', function(event){
//         let req = new XMLHttpRequest();
//         let payload = {name: null, reps: null, weight: null, date: null, unit: null};
//         payload.name = document.getElementById('name').value;
//         payload.reps = document.getElementById('reps').value;
//         payload.weight = document.getElementById('weight').value;
//         payload.date = document.getElementById('date').value;
//         payload.unit = document.getElementById('unit').value;
//         req.open("POST", server,true);
//         req.setRequestHeader('Content-Type','application/json');
//         req.addEventListener('load', function(){
//             if(req.status >=200 && req.status <400){
//                 let response = JSON.parse(req.responseText);
//                 addTable(response)
//                 tableClick()
//             }
//             else{
//                 console.log("uh oh!");
//             }
//         })
//         req.send(JSON.stringify(payload));
//         event.preventDefault();
//     })
// }

// // change the table cells for the target id
// function updateForms(id){
//     let table = document.getElementById('table');
//     let targetRow = null
//     //iterate through table rows
//     for (let i=0, row; row=table.rows[i]; i++){
//         if (row.cells[0].innerText== id) {
//             targetRow = row
//         }
//     }
//     let nameForm = "<input type='text' name='name' id='tablename' value='" + targetRow.cells[1].innerText + "'></input>"
//     let repsForm = "<input type='number' name='reps' id='tablereps' value='" + targetRow.cells[2].innerText + "'></input>"
//     let weightForm = "<input type='number' name='weight' id='tableweight' value='" + targetRow.cells[3].innerText + "'></input>"
//     let dateForm = "<input type='date' name='date' id='tabledate' value='" + targetRow.cells[4].innerText + "'></input>"
//     let unitForm = "<select name ='unit' id = 'tableunit'> <option value='lbs'>lbs</option> <option value='kgs'>kgs</option> </select>"
//     let buttonUpdate = "<td><button id='u" + id + "'>Submit Update</button></td>"

//     targetRow.cells[1].innerHTML = nameForm
//     targetRow.cells[2].innerHTML = repsForm
//     targetRow.cells[3].innerHTML = weightForm
//     targetRow.cells[4].innerHTML = dateForm
//     targetRow.cells[5].innerHTML = unitForm
//     targetRow.cells[7].innerHTML = buttonUpdate
// }

// function tableClick(){
//     document.querySelectorAll('#table td').forEach(e => e.addEventListener("click", function(event){
//         let elem = this.firstElementChild
//         let id = elem.getAttribute('id')
//         let action = id.slice(0,1)
//         let targetId = id.slice(1)
//         if (action == "D"){
//             delData(targetId,event);
//         }
//         if (action == "u"){
//             if (elem.innerText == "Submit Update"){
//                 console.log("submit updated")
//                 updateData(targetId, event);
//             }
//             else{
//                 console.log("update form loaded")
//                 updateForms(targetId);
//             }
//         }
//     },false))
// }

// function delTable(response){
//     console.log(response)
//     let delLength = response.rows.length+2
//     let tableRow = response.rows.length
//     let table = document.getElementById("table")

//     //delete old table
//     for (i=0; i<delLength; i++){
//         table.deleteRow(0)
//     }

//     //Build new table!
//     //Insert headers
//     let row = table.insertRow(-1);
//     let id = row.insertCell(0);
//     let name = row.insertCell(1);
//     let reps = row.insertCell(2);
//     let weight = row.insertCell(3);
//     let date = row.insertCell(4);
//     let unit = row.insertCell(5);
//     id.innerText = "id"
//     name.innerText = "name"
//     reps.innerText = "reps"
//     weight.innerText= "weight"
//     date.innerText = "date"
//     unit.innerText = "unit"
//     id.hidden = true

//     //Insert new row and cells
//     let tableRows = tableRow+1
//     for (i=1; i<tableRows; i++) {
//         let row = table.insertRow(i);
//         let id = row.insertCell(0);
//         let name = row.insertCell(1);
//         let reps = row.insertCell(2);
//         let weight = row.insertCell(3);
//         let date = row.insertCell(4);
//         let unit = row.insertCell(5);
//         let deleteButton = row.insertCell(6);
//         let updateButton = row.insertCell(7);

//         // update content of cells
//         id.innerHTML = response.rows[i-1].id
//         name.innerHTML = response.rows[i-1].name
//         reps.innerHTML = response.rows[i-1].reps
//         weight.innerHTML = response.rows[i-1].weight
//         date.innerHTML = response.rows[i-1].date
//         unit.innerHTML = response.rows[i-1].unit
//         let delString = "<td><button id='D" + response.rows[i-1].id + "'>Delete</button></td>"
//         deleteButton.innerHTML = delString
//         let updateString = "<td><button id='u" + response.rows[i-1].id + "'>Update</button></td>"
//         updateButton.innerHTML = updateString
//         id.hidden = true
//     }
// }

// function addTable(response){
//     console.log(response)
//     let addLen = response.rows.length
//     let tableRow = response.rows.length
//     let table = document.getElementById("table")
//     console.log(tableRow)

//     //delete old table
//     for (i=0; i<addLen; i++){
//         table.deleteRow(0)
//     }

//     //Build new table!
//     //Insert headers
//     let row = table.insertRow(-1);
//     let id = row.insertCell(0);
//     let name = row.insertCell(1);
//     let reps = row.insertCell(2);
//     let weight = row.insertCell(3);
//     let date = row.insertCell(4);
//     let unit = row.insertCell(5);
//     id.innerText = "id"
//     name.innerText = "name"
//     reps.innerText = "reps"
//     weight.innerText= "weight"
//     date.innerText = "date"
//     unit.innerText = "unit"
//     id.hidden = true

//     //Insert new row and cells
//     let tableRows = tableRow+1
//     for (i=1; i<tableRows; i++) {
//         let row = table.insertRow(i);
//         let id = row.insertCell(0);
//         let name = row.insertCell(1);
//         let reps = row.insertCell(2);
//         let weight = row.insertCell(3);
//         let date = row.insertCell(4);
//         let unit = row.insertCell(5);
//         let deleteButton = row.insertCell(6);
//         let updateButton = row.insertCell(7);

//         // update content of cells
//         id.innerHTML = response.rows[i-1].id
//         name.innerHTML = response.rows[i-1].name
//         reps.innerHTML = response.rows[i-1].reps
//         weight.innerHTML = response.rows[i-1].weight
//         date.innerHTML = response.rows[i-1].date
//         unit.innerHTML = response.rows[i-1].unit
//         let delString = "<td><button id='D" + response.rows[i-1].id + "'>Delete</button></td>"
//         deleteButton.innerHTML = delString
//         let updateString = "<td><button id='u" + response.rows[i-1].id + "'>Update</button></td>"
//         updateButton.innerHTML = updateString
//         id.hidden = true
//     }
// }

// function updateTable(response){
//     console.log(response)
//     let updateLength = response.rows.length+1
//     let tableRow = response.rows.length
//     console.log(tableRow)
//     let table = document.getElementById("table")

//     //delete old table
//     for (i=0; i<updateLength; i++){
//         table.deleteRow(0)
//     }

//     //Build new table!
//     //Insert headers
//     let row = table.insertRow(-1);
//     let id = row.insertCell(0);
//     let name = row.insertCell(1);
//     let reps = row.insertCell(2);
//     let weight = row.insertCell(3);
//     let date = row.insertCell(4);
//     let unit = row.insertCell(5);
//     id.innerText = "id"
//     name.innerText = "name"
//     reps.innerText = "reps"
//     weight.innerText= "weight"
//     date.innerText = "date"
//     unit.innerText = "unit"
//     id.hidden = true

//     //Insert new row and cells
//     let tableRows = tableRow+1
//     for (i=1; i<tableRows; i++) {
//         let row = table.insertRow(i);
//         let id = row.insertCell(0);
//         let name = row.insertCell(1);
//         let reps = row.insertCell(2);
//         let weight = row.insertCell(3);
//         let date = row.insertCell(4);
//         let unit = row.insertCell(5);
//         let deleteButton = row.insertCell(6);
//         let updateButton = row.insertCell(7);

//         // update content of cells
//         id.innerHTML = response.rows[i-1].id
//         name.innerHTML = response.rows[i-1].name
//         reps.innerHTML = response.rows[i-1].reps
//         weight.innerHTML = response.rows[i-1].weight
//         date.innerHTML = response.rows[i-1].date
//         unit.innerHTML = response.rows[i-1].unit
//         let delString = "<td><button id='D" + response.rows[i-1].id + "'>Delete</button></td>"
//         deleteButton.innerHTML = delString
//         let updateString = "<td><button id='u" + response.rows[i-1].id + "'>Update</button></td>"
//         updateButton.innerHTML = updateString
//         id.hidden = true
//     }
// }